package AV2;

public class PedidoItem {
    public PedidoItem(String s, int i, double v) {

    }

    public double getPrecoItem() {
        return 0;
    }

    public double getQtdItem() {
        return 0;
    }
}
