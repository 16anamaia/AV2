public class Categoria {
    private String descCategoria;

    public Categoria(String descCategoria) {
        this.descCategoria = descCategoria;
    }
}
